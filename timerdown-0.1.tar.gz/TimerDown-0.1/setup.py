import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
	name='TimerDown',
	version='0.1',
	packages=setuptools.find_packages(),
	package_data={
      'timerdown': ['icons/*.ico'],
   },
	url='https://github.com/Pyntux/TimerDown',
	license='GPLv3',
	author='Pyntux',
	author_email='pyntux@gmail.com',
	description='Small app for schedule Linux PC shutdown',
	install_requires=['pyqt5'],
)
