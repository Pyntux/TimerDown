import setuptools
#from setuptools import setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
	name='TimerDown',
	version='0.2',
	packages= setuptools.find_packages(),
	long_description_content_type="text/markdown",
	url='https://github.com/Pyntux/TimerDown',
	license='GPLv3',
	author='Pyntux',
	author_email='pyntux@gmail.com',
	description='Small app for schedule Linux PC shutdown'
)
